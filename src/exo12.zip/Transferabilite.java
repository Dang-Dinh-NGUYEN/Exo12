public interface Transferabilite {
    boolean estTransferable(Contenant contenant, int quantite);
}
