public interface Ouverture {
    public boolean estOuvert();
}
