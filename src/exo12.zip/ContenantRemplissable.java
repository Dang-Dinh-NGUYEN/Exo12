public interface ContenantRemplissable {
    void setReste(int quantite);
    int getReste();
}
