public class Carafe extends Contenant{

    Carafe(int contenance) {
        super(contenance, 0, new ToujoursOuvert());
    }
}
