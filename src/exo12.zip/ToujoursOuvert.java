public class ToujoursOuvert implements Ouverture{
    @Override
    public boolean estOuvert() {
        return true;
    }
}
