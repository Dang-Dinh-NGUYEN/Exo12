public class Verre extends ContenantBuvable{
    Verre(int contenance){
        super(contenance,0, new ToujoursOuvert());
    }

}
