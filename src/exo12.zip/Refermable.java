public class Refermable extends Ouvrable{

    public void fermer(){
        setOuvert(false);
    }
}
